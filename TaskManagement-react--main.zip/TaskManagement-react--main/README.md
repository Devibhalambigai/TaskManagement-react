# Task Management app using react and express for MERN technology
This is an react based Web page for managing Task.
download the files from this respository and then install express in backend directory and add a file(.env).
in .env file 
            # .env
            MONGO_URI=mongodb://localhost:27017/tasks
            PORT=4000


make a database with name ("tasks") in mongogb
now run backend and front seperetely in two terminals.
